Microsoft.Dynamics.NAV.InvokeExtensibilityMethod("OnControlInit", []);
